package com.chat.model;

public class KafkaConsumer {

    private String groupId;
    private String topicName;
    private String outerObject;
    private String jsonPayload;

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getTopicName() {
        return topicName;
    }

    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }

    public String getOuterObject() {
        return outerObject;
    }

    public void setOuterObject(String outerObject) {
        this.outerObject = outerObject;
    }

    public String getJsonPayload() {
        return jsonPayload;
    }

    public void setJsonPayload(String jsonPayload) {
        this.jsonPayload = jsonPayload;
    }
}
