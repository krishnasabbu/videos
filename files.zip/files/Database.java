package com.chat.model;


public class Database {
    private String tableName;
    private boolean circutBreaker;
    private boolean transactional;
    private String jsonPayload;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public boolean isCircutBreaker() {
        return circutBreaker;
    }

    public void setCircutBreaker(boolean circutBreaker) {
        this.circutBreaker = circutBreaker;
    }

    public boolean isTransactional() {
        return transactional;
    }

    public void setTransactional(boolean transactional) {
        this.transactional = transactional;
    }

    public String getJsonPayload() {
        return jsonPayload;
    }

    public void setJsonPayload(String jsonPayload) {
        this.jsonPayload = jsonPayload;
    }
}
