package com.chat.model;

public class ProjectFeature {

    private String featureName;

    public String getFeatureName() {
        return featureName;
    }

    public void setFeatureName(String featureName) {
        this.featureName = featureName;
    }
}
