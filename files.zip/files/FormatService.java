package com.chat.services;

import com.chat.model.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import java.util.*;

public class FormatService {

    public static void main(String[] args) {
        String jsonString = "{\n" +
                "    \"ROOT\": {\n" +
                "        \"type\": {\n" +
                "            \"resolvedName\": \"Container\"\n" +
                "        },\n" +
                "        \"isCanvas\": true,\n" +
                "        \"props\": {\n" +
                "            \"id\": \"root\"\n" +
                "        },\n" +
                "        \"displayName\": \"Container\",\n" +
                "        \"custom\": {},\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [\n" +
                "            \"XpWheXYcBk\",\n" +
                "            \"SeaITOaHB8\",\n" +
                "            \"L2wkRJXhTJ\"\n" +
                "        ],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"XpWheXYcBk\": {\n" +
                "        \"type\": \"div\",\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"className\": \"textbox-container\"\n" +
                "        },\n" +
                "        \"displayName\": \"div\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"ROOT\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [\n" +
                "            \"ETIpytYGrU\",\n" +
                "            \"kl2DG9mPVe\",\n" +
                "            \"z0pxvE5Cf3\",\n" +
                "            \"2DQMgj3gTu\"\n" +
                "        ],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"ETIpytYGrU\": {\n" +
                "        \"type\": \"div\",\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"className\": \"textbox-item\"\n" +
                "        },\n" +
                "        \"displayName\": \"div\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"XpWheXYcBk\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [\n" +
                "            \"V4csF98DsT\"\n" +
                "        ],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"V4csF98DsT\": {\n" +
                "        \"type\": {\n" +
                "            \"resolvedName\": \"Textbox\"\n" +
                "        },\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"text\": \"Micro\",\n" +
                "            \"fontSize\": 20,\n" +
                "            \"label\": \"Project Name\",\n" +
                "            \"className\": \"text-input\"\n" +
                "        },\n" +
                "        \"displayName\": \"Textbox\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"ETIpytYGrU\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"kl2DG9mPVe\": {\n" +
                "        \"type\": \"div\",\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"className\": \"textbox-item\"\n" +
                "        },\n" +
                "        \"displayName\": \"div\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"XpWheXYcBk\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [\n" +
                "            \"Qr_dc00KBt\"\n" +
                "        ],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"Qr_dc00KBt\": {\n" +
                "        \"type\": {\n" +
                "            \"resolvedName\": \"Textbox\"\n" +
                "        },\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"text\": \"MicroService\",\n" +
                "            \"fontSize\": 20,\n" +
                "            \"label\": \"Project Alias Name\",\n" +
                "            \"className\": \"text-input\"\n" +
                "        },\n" +
                "        \"displayName\": \"Textbox\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"kl2DG9mPVe\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"z0pxvE5Cf3\": {\n" +
                "        \"type\": \"div\",\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"className\": \"textbox-item\"\n" +
                "        },\n" +
                "        \"displayName\": \"div\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"XpWheXYcBk\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [\n" +
                "            \"ggu3LzSXPl\"\n" +
                "        ],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"ggu3LzSXPl\": {\n" +
                "        \"type\": {\n" +
                "            \"resolvedName\": \"Textbox\"\n" +
                "        },\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"text\": \"groupId\",\n" +
                "            \"fontSize\": 20,\n" +
                "            \"label\": \"GroupId\",\n" +
                "            \"className\": \"text-input\"\n" +
                "        },\n" +
                "        \"displayName\": \"Textbox\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"z0pxvE5Cf3\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"2DQMgj3gTu\": {\n" +
                "        \"type\": \"div\",\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"className\": \"textbox-item\"\n" +
                "        },\n" +
                "        \"displayName\": \"div\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"XpWheXYcBk\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [\n" +
                "            \"5FVne2w86H\"\n" +
                "        ],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"5FVne2w86H\": {\n" +
                "        \"type\": {\n" +
                "            \"resolvedName\": \"Textbox\"\n" +
                "        },\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"text\": \"artifactId\",\n" +
                "            \"fontSize\": 20,\n" +
                "            \"label\": \"Artifact Id\",\n" +
                "            \"className\": \"text-input\"\n" +
                "        },\n" +
                "        \"displayName\": \"Textbox\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"2DQMgj3gTu\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"SeaITOaHB8\": {\n" +
                "        \"type\": \"div\",\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"className\": \"textbox-container1\"\n" +
                "        },\n" +
                "        \"displayName\": \"div\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"ROOT\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [\n" +
                "            \"n5FOO7QSl5\"\n" +
                "        ],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"n5FOO7QSl5\": {\n" +
                "        \"type\": \"div\",\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"className\": \"textbox-item\"\n" +
                "        },\n" +
                "        \"displayName\": \"div\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"SeaITOaHB8\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [\n" +
                "            \"Ha6WDjhExi\"\n" +
                "        ],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"Ha6WDjhExi\": {\n" +
                "        \"type\": {\n" +
                "            \"resolvedName\": \"Textbox\"\n" +
                "        },\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"text\": \"c:/ksabbu\",\n" +
                "            \"fontSize\": 20,\n" +
                "            \"label\": \"Project Path\",\n" +
                "            \"className\": \"text-input\"\n" +
                "        },\n" +
                "        \"displayName\": \"Textbox\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"n5FOO7QSl5\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"L2wkRJXhTJ\": {\n" +
                "        \"type\": {\n" +
                "            \"resolvedName\": \"Columns\"\n" +
                "        },\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"numberOfCols\": 3,\n" +
                "            \"gap\": 50\n" +
                "        },\n" +
                "        \"displayName\": \"Columns\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"ROOT\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [],\n" +
                "        \"linkedNodes\": {\n" +
                "            \"column-0\": \"HxFnMkKGp4\",\n" +
                "            \"column-1\": \"gHlPjmgDzk\",\n" +
                "            \"column-2\": \"SQf0BRIpfz\"\n" +
                "        }\n" +
                "    },\n" +
                "    \"HxFnMkKGp4\": {\n" +
                "        \"type\": {\n" +
                "            \"resolvedName\": \"ColumnContent\"\n" +
                "        },\n" +
                "        \"isCanvas\": true,\n" +
                "        \"props\": {\n" +
                "            \"className\": \"col-span-3\",\n" +
                "            \"title\": \"Input Components\",\n" +
                "            \"description\": \"Drag Components here\"\n" +
                "        },\n" +
                "        \"displayName\": \"ColumnContent\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"L2wkRJXhTJ\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [\n" +
                "            \"c07OqOPY3_\"\n" +
                "        ],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"gHlPjmgDzk\": {\n" +
                "        \"type\": {\n" +
                "            \"resolvedName\": \"ColumnContent\"\n" +
                "        },\n" +
                "        \"isCanvas\": true,\n" +
                "        \"props\": {\n" +
                "            \"className\": \"col-span-3\",\n" +
                "            \"title\": \"Business Components\",\n" +
                "            \"description\": \"Drag Business Components here\"\n" +
                "        },\n" +
                "        \"displayName\": \"ColumnContent\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"L2wkRJXhTJ\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [\n" +
                "            \"bamk_c0d8z\",\n" +
                "            \"vmXM9lpTlt\"\n" +
                "        ],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"SQf0BRIpfz\": {\n" +
                "        \"type\": {\n" +
                "            \"resolvedName\": \"ColumnContent\"\n" +
                "        },\n" +
                "        \"isCanvas\": true,\n" +
                "        \"props\": {\n" +
                "            \"className\": \"col-span-3\",\n" +
                "            \"title\": \"Output Components\",\n" +
                "            \"description\": \"Drag Components here\"\n" +
                "        },\n" +
                "        \"displayName\": \"ColumnContent\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"L2wkRJXhTJ\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [\n" +
                "            \"Tni7q79RXC\",\n" +
                "            \"a2yJ94Q01r\",\n" +
                "            \"zYGR4hXfmG\"\n" +
                "        ],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"c07OqOPY3_\": {\n" +
                "        \"type\": {\n" +
                "            \"resolvedName\": \"KafkaConsumer\"\n" +
                "        },\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"groupId\": \"consumerGroupId\",\n" +
                "            \"topicName\": \"consumerTopicName\",\n" +
                "            \"outerObject\": \"consumerObjectName\",\n" +
                "            \"jsonPayload\": \"{\\n  \\\"DeliveryContent\\\": {\\n    \\\"contentType\\\": {\\n\\t   \\\"type\\\": \\\"String\\\",\\n\\t   \\\"mandatory\\\": true\\n\\t},\\n\\t\\\"alertText\\\": {\\n\\t   \\\"type\\\": \\\"String\\\",\\n\\t   \\\"mandatory\\\": true\\n\\t},\\n\\t\\\"messageTypeId\\\": {\\n\\t   \\\"type\\\": \\\"String\\\",\\n\\t   \\\"mandatory\\\": false\\n\\t}\\n  },\\n  \\\"DeliveryMetadata\\\": {\\n    \\\"uowId\\\": {\\n\\t   \\\"type\\\": \\\"String\\\",\\n\\t   \\\"mandatory\\\": true\\n\\t},\\n\\t\\\"sorUowId\\\": {\\n\\t   \\\"type\\\": \\\"String\\\",\\n\\t   \\\"mandatory\\\": true\\n\\t},\\n\\t\\\"inboundUowId\\\": {\\n\\t   \\\"type\\\": \\\"String\\\",\\n\\t   \\\"mandatory\\\": true\\n\\t}\\n  }\\n}\"\n" +
                "        },\n" +
                "        \"displayName\": \"KafkaConsumer\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"HxFnMkKGp4\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"Tni7q79RXC\": {\n" +
                "        \"type\": {\n" +
                "            \"resolvedName\": \"Database\"\n" +
                "        },\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"tableName\": \"table1\",\n" +
                "            \"circutBreaker\": true,\n" +
                "            \"transactional\": true,\n" +
                "            \"jsonPayload\": \"{\\n  \\\"sorUowId\\\": {\\n    \\\"dbName\\\": \\\"SOR_UOWID\\\",\\n\\t\\\"dbType\\\": \\\"String\\\"\\n  },\\n  \\\"uowId\\\": {\\n\\t\\\"dbName\\\": \\\"UOW_ID\\\",\\n\\t\\\"dbType\\\": \\\"String\\\"\\n  },\\n  \\\"inboundUowId\\\": {\\n\\t\\\"dbName\\\": \\\"INBOUND_UOW_ID\\\",\\n\\t\\\"dbType\\\": \\\"String\\\"\\n  },\\n  \\\"contentType\\\": {\\n\\t\\\"dbName\\\": \\\"CONTENT_TYPE\\\",\\n\\t\\\"dbType\\\": \\\"String\\\"\\n  },\\n  \\\"alertText\\\": {\\n\\t\\\"dbName\\\": \\\"ALERT_TEXT\\\",\\n\\t\\\"dbType\\\": \\\"Bytes\\\"\\n  },\\n  \\\"messageTypeId\\\": {\\n\\t\\\"dbName\\\": \\\"MESSAGE_TYPE_ID\\\",\\n\\t\\\"dbType\\\": \\\"Int\\\"\\n  } \\n}\"\n" +
                "        },\n" +
                "        \"displayName\": \"Database\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"SQf0BRIpfz\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"bamk_c0d8z\": {\n" +
                "        \"type\": {\n" +
                "            \"resolvedName\": \"ProjectFeature\"\n" +
                "        },\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"groupId\": \"\",\n" +
                "            \"topicName\": \"\",\n" +
                "            \"outerObject\": \"\",\n" +
                "            \"jsonPayload\": \"\",\n" +
                "            \"featureName\": \"KGH238\"\n" +
                "        },\n" +
                "        \"displayName\": \"ProjectFeature\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"gHlPjmgDzk\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"vmXM9lpTlt\": {\n" +
                "        \"type\": {\n" +
                "            \"resolvedName\": \"Date\"\n" +
                "        },\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"inputFields\": \"dateField\",\n" +
                "            \"outputFields\": \"createdDate\",\n" +
                "            \"inputDateFormat\": \"mm/dd/yyyy\",\n" +
                "            \"outputDateFormat\": \"dd/mm/yyyy\"\n" +
                "        },\n" +
                "        \"displayName\": \"Date\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"gHlPjmgDzk\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"a2yJ94Q01r\": {\n" +
                "        \"type\": {\n" +
                "            \"resolvedName\": \"Database\"\n" +
                "        },\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"tableName\": \"Table2\",\n" +
                "            \"circutBreaker\": true,\n" +
                "            \"transactional\": true,\n" +
                "            \"jsonPayload\": \"{\\n  \\\"sorUowId\\\": {\\n    \\\"dbName\\\": \\\"SOR_UOWID\\\",\\n\\t\\\"dbType\\\": \\\"String\\\"\\n  },\\n  \\\"uowId\\\": {\\n\\t\\\"dbName\\\": \\\"UOW_ID\\\",\\n\\t\\\"dbType\\\": \\\"String\\\"\\n  },\\n  \\\"inboundUowId\\\": {\\n\\t\\\"dbName\\\": \\\"INBOUND_UOW_ID\\\",\\n\\t\\\"dbType\\\": \\\"String\\\"\\n  },\\n  \\\"contentType\\\": {\\n\\t\\\"dbName\\\": \\\"CONTENT_TYPE\\\",\\n\\t\\\"dbType\\\": \\\"String\\\"\\n  },\\n  \\\"alertText\\\": {\\n\\t\\\"dbName\\\": \\\"ALERT_TEXT\\\",\\n\\t\\\"dbType\\\": \\\"Bytes\\\"\\n  },\\n  \\\"messageTypeId\\\": {\\n\\t\\\"dbName\\\": \\\"MESSAGE_TYPE_ID\\\",\\n\\t\\\"dbType\\\": \\\"Int\\\"\\n  } \\n}\"\n" +
                "        },\n" +
                "        \"displayName\": \"Database\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"SQf0BRIpfz\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [],\n" +
                "        \"linkedNodes\": {}\n" +
                "    },\n" +
                "    \"zYGR4hXfmG\": {\n" +
                "        \"type\": {\n" +
                "            \"resolvedName\": \"KafkaProducer\"\n" +
                "        },\n" +
                "        \"isCanvas\": false,\n" +
                "        \"props\": {\n" +
                "            \"groupId\": \"producerGroupId\",\n" +
                "            \"topicName\": \"producerTopicName\",\n" +
                "            \"outerObject\": \"producerObjectName\",\n" +
                "            \"jsonPayload\": \"{\\n  \\\"DeliveryContent\\\": {\\n    \\\"contentType\\\": {\\n\\t   \\\"type\\\": \\\"String\\\",\\n\\t   \\\"mandatory\\\": true\\n\\t},\\n\\t\\\"alertText\\\": {\\n\\t   \\\"type\\\": \\\"String\\\",\\n\\t   \\\"mandatory\\\": true\\n\\t},\\n\\t\\\"messageTypeId\\\": {\\n\\t   \\\"type\\\": \\\"String\\\",\\n\\t   \\\"mandatory\\\": false\\n\\t}\\n  },\\n  \\\"DeliveryMetadata\\\": {\\n    \\\"uowId\\\": {\\n\\t   \\\"type\\\": \\\"String\\\",\\n\\t   \\\"mandatory\\\": true\\n\\t},\\n\\t\\\"sorUowId\\\": {\\n\\t   \\\"type\\\": \\\"String\\\",\\n\\t   \\\"mandatory\\\": true\\n\\t},\\n\\t\\\"inboundUowId\\\": {\\n\\t   \\\"type\\\": \\\"String\\\",\\n\\t   \\\"mandatory\\\": true\\n\\t}\\n  }\\n}\"\n" +
                "        },\n" +
                "        \"displayName\": \"KafkaProducer\",\n" +
                "        \"custom\": {},\n" +
                "        \"parent\": \"SQf0BRIpfz\",\n" +
                "        \"hidden\": false,\n" +
                "        \"nodes\": [],\n" +
                "        \"linkedNodes\": {}\n" +
                "    }\n" +
                "}"; // Input JSON as a string

        try {
            // Parse the JSON string into a JSONObject
            JSONObject inputJson = new JSONObject(jsonString);

            // Prepare the new JSON structure
            LinkedHashMap<String, Object> resultJson = new LinkedHashMap<>();

            // Identify IDs for each property dynamically
            Map<String, String> propertyIds = identifyPropertyIds(inputJson);

            // Extract general properties dynamically
            resultJson.put("projectName", extractProperty(inputJson, propertyIds.get("projectName")));
            resultJson.put("projectAliasName", extractProperty(inputJson, propertyIds.get("projectAliasName")));
            resultJson.put("groupId", extractProperty(inputJson, propertyIds.get("groupId")));
            resultJson.put("artifactId", extractProperty(inputJson, propertyIds.get("artifactId")));
            resultJson.put("path", extractProperty(inputJson, propertyIds.get("path")));

            // Build the "input" section dynamically
            JSONObject inputSection = new JSONObject();
            Map<String, JSONArray> servicesJson = extractJsonPayload(inputJson);

            resultJson.put("Input Components", addSections(inputJson, servicesJson.get("Input Components")));
            resultJson.put("Business Components", addSections(inputJson, servicesJson.get("Business Components")));
            resultJson.put("Output Components", addSections(inputJson, servicesJson.get("Output Components")));


            ObjectMapper objectMapper = new ObjectMapper();


            // Print the resulting JSON
            System.out.println(objectMapper.writeValueAsString(resultJson)); // Pretty print with indentation

        } catch (JSONException e) {
            e.printStackTrace();
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }


    private void iterateJson() {
        Map<String, List<Objects>> map  = new HashMap<>();


    }



    // Method to identify IDs based on properties
    private static Map<String, String> identifyPropertyIds(JSONObject json) throws JSONException {
        Map<String, String> propertyIds = new HashMap<>();
        Iterator<String> keys = json.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            JSONObject node = json.getJSONObject(key);
            if (node.has("props")) {
                JSONObject props = node.getJSONObject("props");
                if (props.has("label")) {
                    String label = props.getString("label");
                    switch (label) {
                        case "Project Name":
                            propertyIds.put("projectName", key);
                            break;
                        case "Project Alias Name":
                            propertyIds.put("projectAliasName", key);
                            break;
                        case "GroupId":
                            propertyIds.put("groupId", key);
                            break;
                        case "Artifact Id":
                            propertyIds.put("artifactId", key);
                            break;
                        case "Project Path":
                            propertyIds.put("path", key);
                            break;
                    }
                }
            }
        }

        return propertyIds;
    }

    // Method to extract property value from a node
    private static String extractProperty(JSONObject json, String id) {
        if (id != null && json.has(id)) {
            JSONObject node = json.getJSONObject(id);
            if (node.has("props") && node.getJSONObject("props").has("text")) {
                return node.getJSONObject("props").getString("text");
            }
        }
        return "";
    }

    // Method to extract JSON payload for a given section type
    private static Map<String, JSONArray> extractJsonPayload(JSONObject json) throws JSONException {

        Map<String, JSONArray> nodesList = new HashMap<>();

        JSONObject sectionPayload = new JSONObject();

        // Use Iterator to go through the keys
        Iterator<String> keys = json.keys();

        while (keys.hasNext()) {
            String key = keys.next();
            JSONObject node = json.getJSONObject(key);
            if (node.has("props") && node.getJSONObject("props").has("title") && node.has("nodes") ) {
                JSONArray jsonArray = node.getJSONArray("nodes");
                nodesList.put(node.getJSONObject("props").getString("title"), jsonArray);
            }
        }

        return nodesList;
    }

    private static LinkedList<Map<String, Object>> addSections(JSONObject inputJson, JSONArray jsonArray) throws JSONException {
        LinkedList<Map<String, Object>> linkedList = new LinkedList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            LinkedHashMap<String, Object> hashMap = new LinkedHashMap<>();
            String value = jsonArray.getString(i);
            JSONObject innerObject = inputJson.getJSONObject(value);
            constructObject(innerObject, hashMap);
            linkedList.add(hashMap);
        }

        return linkedList;
    }

    private static void constructObject(JSONObject innerObject, LinkedHashMap<String, Object> hashMap) {
        if(innerObject.has("displayName")) {
            if("Database".equalsIgnoreCase(innerObject.getString("displayName"))) {
                hashMap.put("Database", createDatabase(innerObject));
            }
            if("KafkaConsumer".equalsIgnoreCase(innerObject.getString("displayName"))) {
                hashMap.put("KafkaConsumer", createKafkaConsumer(innerObject));
            }
            if("KafkaProducer".equalsIgnoreCase(innerObject.getString("displayName"))) {
                hashMap.put("KafkaProducer", createKafkaProducer(innerObject));
            }
            if("ProjectFeature".equalsIgnoreCase(innerObject.getString("displayName"))) {
                hashMap.put("ProjectFeature", createProjectFeature(innerObject));
            }
            if("Date".equalsIgnoreCase(innerObject.getString("displayName"))) {
                hashMap.put("Date", createDate(innerObject));
            }
        }
    }

    private static KafkaConsumer createKafkaConsumer(JSONObject jsonObject) {
        KafkaConsumer kafkaConsumer = new KafkaConsumer();
        if(jsonObject.has("props")) {
            JSONObject innerObject = jsonObject.getJSONObject("props");
            kafkaConsumer.setGroupId(innerObject.getString("groupId"));
            kafkaConsumer.setTopicName(innerObject.getString("topicName"));
            kafkaConsumer.setOuterObject(innerObject.getString("outerObject"));
            kafkaConsumer.setJsonPayload(innerObject.getString("jsonPayload"));
        }
        return kafkaConsumer;
    }

    private static KafkaProducer createKafkaProducer(JSONObject jsonObject) {
        KafkaProducer kafkaProducer = new KafkaProducer();
        if(jsonObject.has("props")) {
            JSONObject innerObject = jsonObject.getJSONObject("props");
            kafkaProducer.setGroupId(innerObject.getString("groupId"));
            kafkaProducer.setTopicName(innerObject.getString("topicName"));
            kafkaProducer.setOuterObject(innerObject.getString("outerObject"));
            kafkaProducer.setJsonPayload(innerObject.getString("jsonPayload"));
        }
        return kafkaProducer;
    }

    private static Database createDatabase(JSONObject jsonObject) {
        Database database = new Database();
        if(jsonObject.has("props")) {
            JSONObject innerObject = jsonObject.getJSONObject("props");
            database.setTableName(innerObject.getString("tableName"));
            database.setCircutBreaker(innerObject.getBoolean("circutBreaker"));
            database.setTransactional(innerObject.getBoolean("transactional"));
            database.setJsonPayload(innerObject.getString("jsonPayload"));
        }
        return database;
    }

    private static ProjectFeature createProjectFeature(JSONObject jsonObject) {
        ProjectFeature projectFeature = new ProjectFeature();
        if(jsonObject.has("props")) {
            JSONObject innerObject = jsonObject.getJSONObject("props");
            projectFeature.setFeatureName(innerObject.getString("featureName"));
        }
        return projectFeature;
    }

    private static DateFormat createDate(JSONObject jsonObject) {
        DateFormat dateFormat = new DateFormat();
        if(jsonObject.has("props")) {
            JSONObject innerObject = jsonObject.getJSONObject("props");
            dateFormat.setInputDateFormat(innerObject.getString("inputDateFormat"));
            dateFormat.setOutputDateFormat(innerObject.getString("outputDateFormat"));
            dateFormat.setInputFields(innerObject.getString("inputFields"));
            dateFormat.setOutputFields(innerObject.getString("outputFields"));
        }
        return dateFormat;
    }

    // Method to add business section
    private static void addBusinessSection(JSONObject inputJson, JSONObject businessSection) throws JSONException {
        Iterator<String> keys = inputJson.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            JSONObject node = inputJson.getJSONObject(key);
            String type = node.getString("type");

            if (type.equals("ProjectFeature")) {
                JSONObject projectFeature = new JSONObject();
                projectFeature.put("featureName", node.getJSONObject("props").optString("featureName", ""));
                businessSection.put("ProjectFeature", projectFeature);
            } else if (type.equals("Date")) {
                JSONObject date = new JSONObject();
                date.put("inputFields", node.getJSONObject("props").optString("inputFields", ""));
                date.put("outputFields", node.getJSONObject("props").optString("outputFields", ""));
                date.put("inputDateFormat", node.getJSONObject("props").optString("inputDateFormat", ""));
                date.put("outputDateFormat", node.getJSONObject("props").optString("outputDateFormat", ""));
                businessSection.put("Date", date);
            }
        }
    }

    // Method to add output section
    private static void addOutputSection(JSONObject inputJson, JSONArray outputSection) throws JSONException {
        Iterator<String> keys = inputJson.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            JSONObject node = inputJson.getJSONObject(key);
            String type = node.getString("type");

            if (type.equals("Database")) {
                JSONObject database = new JSONObject();
                database.put("tableName", node.getJSONObject("props").optString("tableName", ""));
                database.put("circutBreaker", node.getJSONObject("props").optBoolean("circutBreaker", false));
                database.put("transactional", node.getJSONObject("props").optBoolean("transactional", false));
                database.put("jsonPayload", new JSONObject(node.getJSONObject("props").optString("jsonPayload", "{}")));
                outputSection.put(database);
            } else if (type.equals("KafkaProducer")) {
                JSONObject kafkaProducer = new JSONObject();
                kafkaProducer.put("groupId", node.getJSONObject("props").optString("groupId", ""));
                kafkaProducer.put("topicName", node.getJSONObject("props").optString("topicName", ""));
                kafkaProducer.put("outerObject", node.getJSONObject("props").optString("outerObject", ""));
                kafkaProducer.put("jsonPayload", new JSONObject(node.getJSONObject("props").optString("jsonPayload", "{}")));
                outputSection.put(kafkaProducer);
            }
        }
    }
}
